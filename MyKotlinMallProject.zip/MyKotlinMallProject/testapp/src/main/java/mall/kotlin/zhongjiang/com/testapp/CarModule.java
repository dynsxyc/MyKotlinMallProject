package mall.kotlin.zhongjiang.com.testapp;

import dagger.Module;

@Module
public class CarModule {

}
