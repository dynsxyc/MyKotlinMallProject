package com.zhongjiang.kotlin.provider.event

class LoginSuccessEvent {
}