package com.zhongjiang.kotlin.provider.router

class NavigationConstant {
    companion object {
        const val NAVIGATION_DATA_BOOLEAN = "boolean"
    }
}