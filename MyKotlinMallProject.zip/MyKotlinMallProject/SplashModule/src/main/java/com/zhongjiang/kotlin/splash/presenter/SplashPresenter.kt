package com.zhongjiang.kotlin.splash.presenter

import com.zhongjiang.kotlin.base.data.net.entity.UserInfo
import com.zhongjiang.kotlin.base.ext.convert
import com.zhongjiang.kotlin.base.presenter.BasePresenter
import com.zhongjiang.kotlin.base.rx.BaseMaybeObserver
import com.zhongjiang.kotlin.splash.presenter.contract.SplashContract
import javax.inject.Inject

/**
 * Created by dyn on 2018/7/25.
 */
class SplashPresenter @Inject constructor(view: SplashContract.View,model: SplashContract.Model) : BasePresenter<SplashContract.View,SplashContract.Model>(view,model),SplashContract.Presenter {
    override fun requestUserInfo(name: String) {
        mModel.requestUserInfo(name).convert().`as`(bindLifecycle()).subscribe(object :BaseMaybeObserver<UserInfo>(mView){
            override fun onSuccess(t: UserInfo) {
                mView.onGetUserInfo(t)
            }
        })
    }

}