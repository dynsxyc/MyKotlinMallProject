package com.zhongjiang.kotlin.splash.data

class VerificationCodeResuleInfo {
    var code: String = ""

    var showMessage: String = ""

    var status: Int = 0
}