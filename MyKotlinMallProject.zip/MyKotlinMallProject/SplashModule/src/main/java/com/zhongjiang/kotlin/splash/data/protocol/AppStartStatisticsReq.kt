package com.zhongjiang.kotlin.splash.data.protocol

/**
 * Created by dyn on 2018/7/16.
 */
data class AppStartStatisticsReq(val mobile:String, val pwd:String, val verifyCode:String)