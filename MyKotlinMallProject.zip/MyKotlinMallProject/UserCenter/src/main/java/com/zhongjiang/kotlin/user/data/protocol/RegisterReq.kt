package com.zhongjiang.kotlin.user.data.protocol

/**
 * Created by dyn on 2018/7/16.
 */
data class RegisterReq(val id:String ,val pwd:String,val verifyCode:String)