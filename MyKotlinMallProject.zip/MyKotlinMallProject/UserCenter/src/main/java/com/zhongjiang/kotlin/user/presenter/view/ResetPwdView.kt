package com.zhongjiang.kotlin.user.presenter.view

import com.zhongjiang.kotlin.base.presenter.IView

/**
 * Created by dyn on 2018/7/13.
 */
interface ResetPwdView : IView {
    fun onResetPwdResult(result : String)
}