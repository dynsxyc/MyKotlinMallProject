package com.zhongjiang.kotlin.base.rx

/**
 * Created by dyn on 2018/7/16.
 */
class BaseException(val status:Int,val msg:String) :Throwable() {
}