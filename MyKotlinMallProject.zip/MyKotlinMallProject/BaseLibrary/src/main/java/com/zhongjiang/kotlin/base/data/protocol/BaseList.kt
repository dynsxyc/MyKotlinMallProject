package com.zhongjiang.kotlin.base.data.protocol

class BaseList<out  T>(val page:Int,val pageSize:Int,val dataList:T)