package com.zhongjiang.kotlin.base.presenter

interface IModel {
    fun onDestroy()
}