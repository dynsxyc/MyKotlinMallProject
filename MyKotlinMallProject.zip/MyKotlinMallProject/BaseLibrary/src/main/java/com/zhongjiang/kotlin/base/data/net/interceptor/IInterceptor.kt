package com.zhongjiang.kotlin.base.data.net.interceptor

import okhttp3.Interceptor
import okhttp3.Response

class IInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}