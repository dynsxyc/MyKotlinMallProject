package com.zhongjiang.kotlin.base.presenter;

/**
 * Created by QingMei on 2017/8/14.
 * desc:
 */

public interface IFragment extends IView{
}
