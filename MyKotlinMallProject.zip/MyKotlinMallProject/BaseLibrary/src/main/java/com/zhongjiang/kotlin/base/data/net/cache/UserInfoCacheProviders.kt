package com.zhongjiang.kotlin.base.data.net.cache

/**
 * Created by QingMei on 2017/8/17.
 * desc:UserInfo缓存
 */

interface UserInfoCacheProviders//    @LifeCache(duration = 10, timeUnit = TimeUnit.SECONDS)
//    Maybe<UserInfo> getUserInfo(
//            Maybe<UserInfo> userInfoObservable,
//            DynamicKey dynamicKey,
//            EvictDynamicKey evictDynamicKey
//    );
