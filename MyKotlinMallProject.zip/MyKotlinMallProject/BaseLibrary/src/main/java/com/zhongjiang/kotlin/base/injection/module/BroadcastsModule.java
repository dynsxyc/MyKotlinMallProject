package com.zhongjiang.kotlin.base.injection.module;


import com.zhongjiang.kotlin.base.injection.component.BroadcastsComponent;

import dagger.Module;

/**
 * Created by QingMei on 2017/10/14.
 * desc:
 */
@Module(subcomponents = {
        BroadcastsComponent.class
})
public abstract class BroadcastsModule {


}
