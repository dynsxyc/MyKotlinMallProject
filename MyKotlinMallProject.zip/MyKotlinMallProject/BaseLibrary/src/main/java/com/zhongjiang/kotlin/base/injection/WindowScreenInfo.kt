package com.zhongjiang.kotlin.base.injection

class WindowScreenInfo constructor(var width:Int, var height:Int) {
}