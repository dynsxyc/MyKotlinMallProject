package com.zhongjiang.kotlin.base.common

/**
 * Created by dyn on 2018/7/25.
 */
class YouXuanNetInterfaceConstant {
    companion object {
        /**
         * APP打开次数
         */
        const val API_METHOD_APP_INSERT_OPEN_NUMBER = "app/other/openApp/insertOpenNumber"
        /**
         * 启动页广告
         */
        const val API_METHOD_APP_APLASH_AD = "app/qt/appStartPage/queryList"
    }
}