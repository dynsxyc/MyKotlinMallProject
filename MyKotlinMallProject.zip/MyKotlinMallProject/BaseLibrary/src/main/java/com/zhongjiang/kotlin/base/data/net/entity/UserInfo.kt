package com.zhongjiang.kotlin.base.data.net.entity

/**
 * Created by QingMei on 2017/8/15.
 * desc:
 */

data class UserInfo(var  name: String,var login:String)