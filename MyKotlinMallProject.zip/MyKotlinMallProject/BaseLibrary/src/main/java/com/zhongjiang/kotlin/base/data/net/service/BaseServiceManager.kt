package com.zhongjiang.kotlin.base.data.net.service

/**
 * Created by QingMei on 2017/8/15.
 * desc:
 */

interface BaseServiceManager {
    fun destroy()
}
