package com.zhongjiang.kotlin.base.rx

import com.zhongjiang.kotlin.base.common.ResultCode.Companion.SUCCESS
import com.zhongjiang.kotlin.base.data.protocol.BaseResp
import io.reactivex.Maybe
import io.reactivex.MaybeSource
import io.reactivex.functions.Function

/**
 * Created by dyn on 2018/7/17.
 */
class BaseFunc<T> : Function<BaseResp<T>, MaybeSource<T>> {
    override fun apply(t: BaseResp<T>): MaybeSource<T> {
        if (t.status != SUCCESS){
            return Maybe.error(BaseException(t.status,t.showMessage))
        }
        return Maybe.just(t.data)
    }
}