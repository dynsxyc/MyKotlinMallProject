package com.zhongjiang.kotlin.base.ui.fragment

open class BaseFragment : BaseInjectFragment()