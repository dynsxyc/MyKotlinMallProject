package com.zhongjiang.kotlin.base.rx

import com.zhongjiang.kotlin.base.presenter.IView
import io.reactivex.MaybeObserver
import io.reactivex.disposables.Disposable

/**
 * Created by dyn on 2018/7/13.
 * 订阅
 */
open class BaseMaybeObserver<T>(val iView: IView) : MaybeObserver<T> {
    override fun onError(e: Throwable) {
        iView.hideLoading()
        if (e is BaseException){
            iView.onError(e.msg)
        }
    }

    override fun onSuccess(t: T) {
    }

    override fun onComplete() {
        iView.hideLoading()
    }

    override fun onSubscribe(d: Disposable) {
    }

}