package com.zhongjiang.kotlin.base.data

/**
 * Created by dyn on 2018/10/11.
 */
interface NetConstantField {
    companion object {
        val API_DATA_DATA = "data"
        val API_DATA_V = "_v"
        val API_DATA_TIMESTAMP = "timestamp"
        val API_DATA_NONCE = "nonce"
        val API_DATA_TICKET = "ticket"
        val API_DATA_SIGNATURE = "signature"

    }
}