package com.zhongjiang.kotlin.base.common

/**
 * Created by dyn on 2018/7/16.
 */
class ResultCode {
//    companion object的意思相当于Java中public static
    companion object {
        val SUCCESS = 1
    }
}